<?php 

/*Template Name: Home Page*/

get_header(); ?>


  <div id="banner-carousel" class="carousel slide" data-ride="carousel">




  <div class="banner banner-slider" >
     <!-- <ol class="carousel-indicators">
     <?php 
        $i = 0;
          if( have_rows('banner') ): 
          while( have_rows('banner') ): the_row();
      ?>
        <li data-target="#banner-carousel" data-slide-to="<?php echo $i; ?>" class="<?php echo ($i == 0) ? 'active' : ''; ?>"></li>
          <?php $i++; endwhile; ?>
        <?php endif; ?>
    </ol> -->
   
   <?php 
      $cntr = 0;
      if( have_rows('banner') ): 
      while( have_rows('banner') ): the_row();
      $banner_image= get_sub_field('banner_image');
      $banner_title= get_sub_field('banner_content_title');
      $banner_content= get_sub_field('banner_content_desc');
    ?>
    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox" style="background: url('<?php echo $banner_image; ?>') no-repeat;">
      <div class="item <?php echo ($cntr == 0) ? 'active' : ''; ?>">
        <div class="container">
            <div class="carousel-caption">
                <h1 class= "carousel-title animated pulse">
                  <?php echo $banner_title; ?>
                </h1>

                <div class="banner-content">
                  <a href="<?php echo get_post_permalink(18); ?>" class="btn btn-info hvr-grow-shadow" role="button">Learn More <i class="fa fa-long-arrow-right"></i></a>
                </div>
              </div>
          </div>
      </div>

      <!-- Controls -->
     <!--  <a class="left carousel-control" href="#banner-carousel" role="button" data-slide="prev">
        <span class="icon-banner icon-left-arrow"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="right carousel-control" href="#banner-carousel" role="button" data-slide="next">
        <span class="icon-banner icon-right-arrow"></span>
        <span class="sr-only">Next</span>
      </a> -->
    </div>

      <?php $cntr++; endwhile; ?>
  <?php endif; ?>

    </div>
</div>










<div class="section skin-gray section-aboutus">
  <div class="container">
    <div class="section-title">
      <h2>About Us</h2>
      <div class="cline-13"></div>
    </div>
    <div class="section-content">

      <div class="section-desc">
        <p>
          <?php 
            $content_post = get_post(25);
            $content = $content_post->post_content;
            $content = str_replace(']]>', ']]&gt;', $content);
            echo $content;
          ?>
        </p>
        <a class="btn btn-default btn-about btn-aboutc icon-arrow-right hvr-grow" href="<?php echo get_post_permalink(18); ?>" role="button">Read More</a>
      </div>
    </div>
  </div>
</div>

   <div class="section section-ourteam">
    <div class="container p-0">
      <div class="section-title">
        <h2>Our Team</h2>
        <div class="cline-13"></div>
      </div>
      <div class="section-content">
        <div class="section-desc">
          <p>
            <?php 
              $content_post = get_post(54);
              $content = $content_post->post_content;
              $content = str_replace(']]>', ']]&gt;', $content);
              echo $content;
            ?>
          </p>
          <a class="btn btn-default btn-about btn-aboutc icon-arrow-right hvr-grow" href="<?php echo get_post_permalink(2); ?>" role="button">Read More</a>
        </div>

      </div>
    </div>
   </div>

   <div class="section skin-gray section-contactus">
     <div class="container p-0">
       <div class="section-title">
         <h2>Contact Us</h2>
         <div class="cline-13"></div>
       </div>
       <div class="section-content">
         <div class="section-desc">
           <p><?php echo get_field('contact_us_desc', 12); ?></p>
           <a class="btn btn-default btn-about btn-aboutc icon-arrow-right hvr-grow" href="<?php echo get_post_permalink(12); ?>" role="button">Read More</a>
         </div>
       </div>
     </div>
   </div>

<?php get_footer(); ?>