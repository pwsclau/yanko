<?php 
/*Template Name: Forms Page*/

get_header(); ?>
<div class="subpage-banner" style="background: #000 url('<?php echo the_field('subbanner_image'); ?>') no-repeat;">
		
		<h1 class="heading-46 ">
			<?php the_title(); ?>
		</h1>
	</div>
<?php get_footer(); ?>